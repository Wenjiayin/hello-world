#include <iostream>
#include <algorithm> 
#include <cstring> 
using namespace std;
#define nmax 110
#define inf 9999999
int minpath,n,m,en,edge[nmax][nmax],mark[nmax];//���·�����ڵ������������յ㣬�ڽӾ��󣬽ڵ���ʱ��
void dfs(int cur,int dst){
    if(minpath<dst) 
		return;
    if(cur==en){
       if(minpath>dst){
        minpath=dst;
        return;
       }
    }
     for(int i=1;i<=n;i++){
        if(mark[i]==0&&edge[cur][i]!=inf&&edge[cur][i]!=0){
            mark[i]=1;
            dfs(i,dst+edge[cur][i]);
            mark[i]=0;
        }
     }
     return;
}
int main ()
{
    cin>>n>>m;
    for(int i=1;i<=n;i++)
	{
        for(int j=1;j<=n;j++)
		{
            edge[i][j]=inf;
        }
        edge[i][i]=0;
    }
    int a,b;
    while(m--){
		cin>>a>>b;
        cin>>edge[a][b];
    }
    minpath=inf;
    memset(mark,0,sizeof(mark));
    mark[1]=1;
    en=n;
    dfs(1,0);
    cout<<minpath;
    return 0;
}
