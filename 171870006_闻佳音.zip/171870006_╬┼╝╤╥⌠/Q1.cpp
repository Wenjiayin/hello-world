#include<algorithm>
#include<cstring>
#include<cstdio>
#include<iostream>
using namespace std;
string str[1005];
int cmp(string a,string b)
{
    return a.compare(b)<0;
}
int main()
{
	char ch;
	cin>>ch;
	int num;
	int N=31;
    for (int i=0; i<N; i++)
    {
        cin>>str[i];    	
        if(str[i][0]=='@')
        {
        	num=i;
        	break;
		}
	}
//	cout<<num<<endl;
	for(int i=0;i<num;i++)
	{
		int len=str[i].size();
		for(int j=0;j<len;j++)
		{
			if(str[i][j]==ch)
			{
				for(int k=j;k<len;k++)
				{
					str[i][k]=str[i][k+1];
				}
				len--;
			}
		}
	}
    sort(str, str+num, cmp);
    for (int i=num-1; i>0; i--)
        cout<<str[i]<<endl;  
	cout<<str[0]; 
    return 0;
}

