#include<iostream> 
#include<cstring> 
#include<cstdio> 
#include<algorithm> 
using namespace std; 
int a[500][4],sum1[1000000],sum2[1000000]; 
int main() 
{ 
	int n,mid,i,j; 
	cin>>n;	
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<4;j++)
		{
			cin>>a[i][j];
		}
	}
	int k=0,m=0; 
	for(i=0;i<n;i++) 
		for(j=0;j<n;j++) 
		{ 
			sum1[k++]=a[i][0]+a[j][1];
			sum2[m++]=a[i][2]+a[j][3];
		} 
		sort(sum2,sum2+k); 
		int cnt=0; 
		for(i=0;i<k;i++) 	
		{ 	
			int left=0; 	
			int right=k-1;
			while(left<right) 	
			{	
				mid=(left+right)/2; 	
				if(sum1[i]+sum2[mid]==0) 
				{	
					cnt++; 
					for(j=mid+1;j<k;j++) 
					{ 
						if(sum1[i]+sum2[j]!=0) 
							break; 
						else 
							cnt++; 
					} 
					for(j=mid-1;j>=0;j--) 
					{ 
						if(sum1[i]+sum2[j]!=0) 
							break; 
						else 
							cnt++; 
					} 
					break; 
				} 
				if(sum1[i]+sum2[mid]<0) 
					left=mid+1; 
				else 
					right=mid;
			} 
		} 
	cout<<cnt;
	return 0; 
}

